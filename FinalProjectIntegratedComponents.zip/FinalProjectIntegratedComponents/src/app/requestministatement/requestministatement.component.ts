import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-requestministatement',
  templateUrl: './requestministatement.component.html',
  styleUrls: ['./requestministatement.component.css']
})
export class RequestministatementComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
