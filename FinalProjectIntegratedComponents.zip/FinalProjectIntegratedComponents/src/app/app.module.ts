import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { HeaderComponent } from './header/header.component';
import { HomeComponent } from './home/home.component';

import { AccountsComponent } from './accounts/accounts.component';
import { FooterComponent } from './footer/footer.component';
import { SuccessComponent } from './success/success.component';
import { EnquiryComponent } from './enquiry/enquiry.component';
import { CheckbalanceComponent } from './checkbalance/checkbalance.component';
import { RequestministatementComponent } from './requestministatement/requestministatement.component';
import { RequestmonannperstatementComponent } from './requestmonannperstatement/requestmonannperstatement.component';
import { TransferfundsComponent } from './transferfunds/transferfunds.component';
import { PayutilitybillsComponent } from './payutilitybills/payutilitybills.component';
import { TranactionsComponent } from './tranactions/tranactions.component';
import { LoginComponent } from './login/login.component';
import { NewregistrationComponent } from './newregistration/newregistration.component';
import { FormsModule,ReactiveFormsModule} from '@angular/forms';
import { BeneficiaryComponent } from './beneficiary/beneficiary.component';


@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    HomeComponent,
   
    AccountsComponent,
    FooterComponent,
    SuccessComponent,
    EnquiryComponent,
    CheckbalanceComponent,
    RequestministatementComponent,
    RequestmonannperstatementComponent,
    TransferfundsComponent,
    PayutilitybillsComponent,
    TranactionsComponent,
    LoginComponent,
    NewregistrationComponent,
    BeneficiaryComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FontAwesomeModule,
    FormsModule,
    ReactiveFormsModule

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
