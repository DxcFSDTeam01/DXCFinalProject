import { Checkbalance } from './checkbalance';

describe('Checkbalance', () => {
  it('should create an instance', () => {
    expect(new Checkbalance()).toBeTruthy();
  });
});
