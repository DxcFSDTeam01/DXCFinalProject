export class Reoccuringdepositaccount {
    public monthlyDeposit;
}
