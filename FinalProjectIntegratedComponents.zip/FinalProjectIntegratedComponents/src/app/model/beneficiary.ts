export class Beneficiary {
    public accountNumber: string;
    public accountHolderName: string;
    public ifscCode: string;
    public accountType: string;
    public transferType: string;
}
