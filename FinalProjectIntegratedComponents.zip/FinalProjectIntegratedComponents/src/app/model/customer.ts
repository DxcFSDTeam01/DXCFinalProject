import { Cards } from './cards';

export class Customer {
    public customerId: string;
    public customerName: string;
    public customerPhonenumber: string;
    public account: Account;
    public aadharCard: number;
    public address: string;
    public panCard: string;
    public password: string;
    public cards: Cards[];
}
