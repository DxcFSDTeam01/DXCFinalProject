export class Bankrepresentative {

    public name: string;
    public representativeId: string;

}
