export const environment = {
  production: true,
  appTitle: "Integrated Banking System",
  logo:"IBS",
};
